#ifndef VERSION_H
#define VERSION_H

namespace AutoVersion{

	//Date Version Types
	static const char DATE[] = "01";
	static const char MONTH[] = "03";
	static const char YEAR[] = "2009";
	static const double UBUNTU_VERSION_STYLE = 9.03;

	//Software Status
	static const char STATUS[] = "Release";
	static const char STATUS_SHORT[] = "r";

	//Standard Version Type
	static const long MAJOR = 4;
	static const long MINOR = 0;
	static const long BUILD = 0;
	static const long REVISION = 0;

	//Miscellaneous Version Types
	static const long BUILDS_COUNT = 1;
	#define RC_FILEVERSION 4,0,0,0
	#define RC_FILEVERSION_STRING "4, 0, 0, 0\0"
	static const char FULLVERSION_STRING[] = "4.0.0.0";

	//SVN Version
	static const char SVN_REVISION[] = "55";
	static const char SVN_DATE[] = "2009-03-01T13:55:03.422671Z";

	//These values are to keep track of your versioning state, don't modify them.
	static const long BUILD_HISTORY = 0;


}
#endif //VERSION_h
